package org.contenido.excepcion;

public class SuperAdminExcepcion extends RuntimeException {
    public SuperAdminExcepcion(String message) {
        super(message);
    }
}
