package org.contenido.excepcion;

public class FormatoExportacionExcepcion extends RuntimeException {
    public FormatoExportacionExcepcion(String message) {
        super(message);
    }
}
