package org.contenido.validacion;
// validacion en grupos con Jakarta Bean Validation
// interface que sirve como marcador de grupo
public interface EnLeer { }
