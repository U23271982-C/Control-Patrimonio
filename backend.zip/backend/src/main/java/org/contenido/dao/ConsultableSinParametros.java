package org.contenido.dao;

import java.util.List;

public interface ConsultableSinParametros {
    List<Object[]> consultarSinParametros();
}
