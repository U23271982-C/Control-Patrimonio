package org.contenido.dao;

public interface Eliminable <T> {
    void eliminar (int idEntidad);
}
