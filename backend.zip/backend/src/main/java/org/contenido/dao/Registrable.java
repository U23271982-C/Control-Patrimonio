package org.contenido.dao;

public interface Registrable<T> {
    void registrar(T entidad);
}
