package org.contenido.dao;

public interface Actualizable <T>{
    void actualizar (T entidad);
}
