package org.contenido.dao;

public interface Leible <T> {
    T leerPorId(int idEntidad);
}
