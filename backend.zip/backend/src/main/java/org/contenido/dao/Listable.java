package org.contenido.dao;

import java.util.List;

public interface Listable<T>{
    List<T> listarTodo();
}
